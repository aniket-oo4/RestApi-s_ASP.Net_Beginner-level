function getDataWithToken() {
    fetchData();
  }
  
  const apiUrl = "http://localhost:53842/api/LeaveApi/1";
  
  // Your JWT token
  const jwtToken ="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhbmlrZXQiLCJyb2xlIjoiYW5pa2V0IiwiZXhwIjoiMjAyNC0wOC0yOVQwNjoxMjo1Ny43NzE5NiswMDowMCJ9.0roNPHvWEOlhLQznAwmhS5-6ywm1sc-2BLkDRaio0Rk"; 
  async function fetchData() {
    try {
      const response = await fetch(apiUrl, {
        method: "GET",
        headers: {
          Authorization: `Bearer ${jwtToken}`,
          "Content-Type": "application/json",
        },
      });
  
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
  
      // Parse the response JSON
      const data = await response.json();
      const allData=data;
      console.log("Fetched  DAta Successfully With Token ::" , allData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }
   